package org.compiler.backend

import org.compiler.frontend.intermediate.models.Address
import org.compiler.frontend.intermediate.models.Goto
import org.compiler.frontend.intermediate.models.IfFalseGoto
import org.compiler.frontend.intermediate.models.IfGoto
import org.compiler.frontend.intermediate.models.IfRelationalGoto
import org.compiler.frontend.intermediate.models.Label
import org.compiler.frontend.intermediate.models.LabelDefinition
import org.compiler.frontend.intermediate.models.Name
import org.compiler.frontend.intermediate.models.Return
import org.compiler.frontend.intermediate.models.Temporary
import org.compiler.frontend.intermediate.models.Throw
import org.compiler.frontend.intermediate.models.TryBegin

/**
 * Que temporales siguen vivos al salir de cada bloque basico: el analisis de vivacidad
 * de siempre, hacia atras sobre el grafo de flujo (Dragon Book 9.2.5).
 *
 *     vivosAlSalir(B)  = union de vivosAlEntrar(S), para cada sucesor S de B
 *     vivosAlEntrar(B) = leidos(B) + (vivosAlSalir(B) - escritos(B))
 *
 * Se repite hasta que ninguno de los dos conjuntos cambia. Los ciclos no son un problema
 * porque los conjuntos solo crecen y son finitos.
 *
 * **Para que sirve.** El vaciado del final de un bloque decide con esto a que registros
 * les toca un `str`. Mirar la instruccion que sigue EN EL ARCHIVO no alcanza: la rama
 * verdadera de un ternario termina en `goto`, y lo que esta escrito despues de ese goto
 * es la OTRA rama, que vuelve a escribir el mismo temporal. Leido en orden de archivo el
 * temporal parece muerto y no se guarda; por el grafo esta vivo, porque el camino real
 * va a la etiqueta de abajo, donde se lee. Sin el grafo, esa rama imprime basura.
 *
 * **Por que solo los temporales.** Una variable del programa puede leerse desde otra
 * funcion, o despues de volver de esta, y el grafo de UNA funcion no lo puede saber. Se
 * guardan siempre, que es lo que ya hacia el generador.
 */
class BlockLiveness(private val blocks: List<BasicBlock>) {

    // Por numero de bloque: los temporales que algun camino de salida vuelve a leer.
    private val liveOut: List<Set<Address>> = solve()

    /** Si una direccion sigue viva al salir del bloque numero `index`. */
    fun liveAtExitOf(index: Int): (Address) -> Boolean {
        val live = liveOut[index]
        return { address -> address is Name || address in live }
    }

    private fun solve(): List<Set<Address>> {
        val read = blocks.map { readBeforeWrittenIn(it) }
        val written = blocks.map { block ->
            block.instructions.mapNotNull { definitionOf(it) }.filterIsInstance<Temporary>().toSet()
        }
        val successors = blocks.indices.map { successorsOf(it) }

        val atExit = MutableList(blocks.size) { emptySet<Address>() }
        val atEntry = MutableList(blocks.size) { emptySet<Address>() }

        // De atras hacia adelante, que es el orden en que la informacion se propaga: asi
        // una pasada sola suele bastar para todo lo que no sea un ciclo.
        var changed = true
        while (changed) {
            changed = false
            for (index in blocks.indices.reversed()) {
                val exit = successors[index].flatMapTo(mutableSetOf()) { atEntry[it] }
                val entry = read[index] + (exit - written[index])
                if (exit != atExit[index] || entry != atEntry[index]) {
                    atExit[index] = exit
                    atEntry[index] = entry
                    changed = true
                }
            }
        }
        return atExit
    }

    // Los temporales que el bloque lee antes de escribirlos. Esos los necesita vivos al
    // entrar, pase lo que pase despues; uno que el bloque escribe primero, no.
    private fun readBeforeWrittenIn(block: BasicBlock): Set<Address> {
        val read = mutableSetOf<Address>()
        val written = mutableSetOf<Address>()
        block.instructions.forEach { quadruple ->
            usesOf(quadruple).filterIsInstance<Temporary>().forEach { if (it !in written) read += it }
            (definitionOf(quadruple) as? Temporary)?.let { written += it }
        }
        return read
    }

    /**
     * Por donde puede seguir el flujo al salir del bloque.
     *
     * Un salto condicional tiene dos salidas: la etiqueta y la instruccion de abajo. Uno
     * incondicional, solo la etiqueta. `return` y `throw` no tienen ninguna: el registro
     * de activacion se muere ahi, y con el sus temporales. El ultimo bloque de la funcion
     * tampoco tiene, por lo mismo.
     */
    private fun successorsOf(index: Int): List<Int> {
        val fallthrough = (index + 1).takeIf { it in blocks.indices }
        return when (val last = blocks[index].instructions.last()) {
            is Goto -> listOfNotNull(blockAt(last.label))
            is IfGoto -> listOfNotNull(blockAt(last.label), fallthrough)
            is IfFalseGoto -> listOfNotNull(blockAt(last.label), fallthrough)
            is IfRelationalGoto -> listOfNotNull(blockAt(last.label), fallthrough)
            is TryBegin -> listOfNotNull(blockAt(last.handler), fallthrough)
            is Return, is Throw -> emptyList()
            else -> listOfNotNull(fallthrough)
        }
    }

    // El bloque que abre esa etiqueta. Siempre abre uno, porque toda etiqueta es lider.
    private fun blockAt(label: Label): Int? =
        blocks.indexOfFirst { (it.instructions.first() as? LabelDefinition)?.label == label }
            .takeIf { it >= 0 }
}
